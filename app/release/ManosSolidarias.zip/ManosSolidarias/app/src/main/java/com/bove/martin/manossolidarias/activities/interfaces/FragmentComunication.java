package com.bove.martin.manossolidarias.activities.interfaces;

import com.bove.martin.manossolidarias.model.Institucion;

/**
 * Created by Martín Bove on 23/07/2018.
 * E-mail: mbove77@gmail.com
 */
public interface FragmentComunication {
    void enviarONG(Institucion institucion);
}
